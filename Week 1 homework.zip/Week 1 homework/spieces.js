class Bird {
  constructor(name) {
    this.name = name;
    this.feet = 2;
    this.tail = 1;
    this.wings = 2;
  }
}

class Parrot extends Bird {
  constructor(name) {
    super(name);
    this.talk = true;
    this.feathers = "colorful";
  }
}

class Hummingbird extends Bird {
  constructor(name) {
    super(name);
    this.talk = false;
    this.hum = true;
    this.size = "tiny";
  }
}

class Penguin extends Bird {
  constructor(name) {
    super(name);
    this.talk = false;
    this.swim = true;
    this.colors = "Black & White";
  }
}

class Owl extends Bird {
  constructor(name) {
    super(name);
    this.talk = false;
    this.hum = false;

  }
}

var Max = new Owl("Max");
var Katie = new Hummingbird("Katie");
var Pattie = new Parrot("Pattie");

document.getElementById("zooBtn").addEventListener("click", function() {

  console.log("The " + Parrot.name +" "+  Pattie.name+ " fanned open her " + Pattie.feathers + " feathers and smacked the " + Hummingbird.name + " " + Katie.name + " so hard the " +
Owl.name + " "+ Max.name + " flapped her "+ Max.wings +" to see the damage but " + Max.feet + " feet got stuck on the oliver branch" );

document.write("The " + Parrot.name +" "+  Pattie.name+ " fanned open his " + Pattie.feathers + " feathers and smacked the " + Hummingbird.name + " " + Katie.name + " so hard the " +
Owl.name + " "+ Max.name + " flapped his "+ Max.wings +" to see the damage but " + Max.feet + " feet got stuck on the oliver branch" );

});